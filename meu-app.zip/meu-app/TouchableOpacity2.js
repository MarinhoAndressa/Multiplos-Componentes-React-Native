import React from 'react';
import { TouchableOpacity2, Text, Alert } from 'react-native';

const TouchableOpacity2 = () => (
 
<TouchableOpacity2 onPress={() => Alert.alert('Item tocado!')}>
<Text>Toque Aqui</Text>
</TouchableOpacity2>
);

export default TouchableOpacity2;