import React from 'react';
import { ActivityIndicator, View } from 'react-native';

const App = () => (

<View>
<ActivityIndicator size="large" color="#0000ff" />
</View>
);

export default App;