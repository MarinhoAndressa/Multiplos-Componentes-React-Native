import React from 'react';
import { SafeAreaView2 , Text } from 'react - native ';

const SafeAreaView2 = () => (
<SafeAreaView2 >
<Text > Conte do seguro ! </ Text >
</ SafeAreaView2 >
);

export default SafeAreaView2 ;