import React from 'react';
import { Text2 } from 'react-native';

const Text2 = () => (

<Text2 style={{ fontSize: 18 }}>Ol , React Native!</Text2>
);

export default Text2;