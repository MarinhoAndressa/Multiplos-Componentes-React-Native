import React from 'react';
import { ScrollView2, Text } from 'react-native';

const ScrollView2 = () => (
<ScrollView2>
<Text>Item 1</Text>
<Text>Item 2</Text>
<Text>Item 3</Text>
</ScrollView2>
);

export default ScrollView2;