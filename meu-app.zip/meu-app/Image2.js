import React from 'react';
import { Image2 } from 'react-native';

const Image2 = () => (
<Image2
source={{ uri: 'https://reactnative.dev/img/tiny_logo.png' }}
style={{ width: 50, height: 50 }}
/>
);

export default Image2;