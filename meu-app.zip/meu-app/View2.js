import React from 'react';
import { View2 , Text } from 'react - native';

const View2 = () => (
<View2 style ={{ padding : 20 }} >
<Text > Estrutura com View </ Text >
</View2 >
 );

export default View2 ;
